package ai2018.group25;

import genius.core.Bid;
import genius.core.boaframework.OpponentModel;

public class Group25_OM extends OpponentModel {

	@Override
	protected void updateModel(Bid bid, double time) {
		// TODO Auto-generated method stub
	}

}
