package ai2018.group25;

import genius.core.bidding.BidDetails;
import genius.core.boaframework.OfferingStrategy;

public class Group25_BS extends OfferingStrategy {

	@Override
	public BidDetails determineOpeningBid() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BidDetails determineNextBid() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		return "Group 25 Offering Strategy";
	}

}
