package ai2018.group25;

public class Group25_Party {

}
