This deliverable has:
   -> The pdf file with the report
   -> The boarepository.xml with the paths of the .class to include to have what our group has 
      done until now
   -> the bin directory where the .class files are
	- Until now, we have the file of the Acceptance Strategy that is working
        - We also have the .class of a Constant Bid strategy, that basically just bids always the same, this
	  was done just to test the Acceptance Strategy
   -> the ai2018 directory, where the source code is
	- Only the source code of Group25_AS.java must be taken into account, as the others are not done yet